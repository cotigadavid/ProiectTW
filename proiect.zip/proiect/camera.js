
function ServiciuSelected(item) {

    window.location.href = "Frizeri.html";

    localStorage.setItem("Serviciu", item.id);
}

function FrizerSelected(item) {

    window.location.href = "SelectDate.html";

    localStorage.setItem("Frizer", item.id);
}

function ChangeHTML() {

    var form = document.getElementById("form");

    localStorage.setItem("time", document.getElementById("time").value)
    form.remove();

    var text = document.createElement("p");
    var timeString = localStorage.getItem("time");
    timeString = timeString.replace("T", " la ora ");
    text.textContent = "Felicitari, ai facut o programare la data de " + timeString + " la frizerul " + localStorage.getItem("Frizer");
    text.setAttribute("style", "font-size:30px; padding-top:150px;");
    text.classList.add("FinText");
    const section = document.getElementsByClassName("section-middle");

    section[0].appendChild(text);
}

function Submitted() {

    if (ValidateForm()) {
        setTimeout(function() {
            ChangeHTML();
        }, 1000);
    }
}

function ValidateForm()
{
    const tel = document.getElementById("tel").value;
    const telRegex = /^\d{10}$/;
    if (!telRegex.test(tel)) {
        alert("Invalid phone number. It must be a 10-digit number.");
        return false;
    }

    const mail = document.getElementById("mail").value;
    const mailRegex = /^$|\s+/;
    if (mailRegex.test(mail)){
        alert("Invalid email address.");
        return false;
    }

    const name = document.getElementById("name").value;
    const nameRegex = /^$/;
    if (nameRegex.test(name)){
        alert("Please fill in your name.");
        return false;
    }

    return true;
}

window.onload = function() {

    var servicii = document.getElementsByClassName("serviciu");

    for (let i = 0; i < servicii.length; ++i)
        servicii[i].addEventListener("click", function() { ServiciuSelected(this) });

    var frizeri = document.getElementsByClassName("frizer");

    for (let i = 0; i < frizeri.length; ++i)
        frizeri[i].addEventListener("click", function() { FrizerSelected(this) });

    var subButton = document.getElementById("subButton");
    subButton.addEventListener("click", function() { Submitted() });

    
}
